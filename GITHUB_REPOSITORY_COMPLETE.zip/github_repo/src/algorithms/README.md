# Algorithms Implementation

Python implementations of core algorithms from the paper.

## Files

- `credibility.py` - Algorithm 1: Adaptive Credibility Learning (O(log 1/ε) convergence)
- `aggregation.py` - Algorithm 2: Multi-Source Aggregation
- `server.py` - FastAPI server exposing algorithms

## Quick Start

```python
from algorithms.credibility import AdaptiveCredibilityTracker

tracker = AdaptiveCredibilityTracker(['ga4', 'mixpanel', 'posthog'])
credibility = tracker.update_credibility()
```

See main README for detailed examples.
