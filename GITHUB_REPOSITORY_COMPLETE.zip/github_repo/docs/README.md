# Documentation

Complete documentation for the Streaming Multi-Expert system.

## Available Guides

- **[SETUP.md](SETUP.md)** - Installation and configuration
- **[API.md](API.md)** - REST API reference
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System design
- **[DEPLOYMENT.md](DEPLOYMENT.md)** - Production deployment
- **[ALGORITHMS.md](ALGORITHMS.md)** - Mathematical details

## Quick Links

- [GitHub Repository](https://github.com/rmehreen/streaming-multi-expert)
- [Paper PDF](https://arxiv.org/abs/XXXX.XXXXX) (coming soon)
- [Issues](https://github.com/rmehreen/streaming-multi-expert/issues)
