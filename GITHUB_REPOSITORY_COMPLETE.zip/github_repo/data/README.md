# Data Directory

## What's Included

✅ Synthetic benchmarks (180 test scenarios)  
✅ Validation scripts  
✅ Sample configurations  

## Not Included

❌ Production deployment logs (confidential)  
❌ Real website analytics data (privacy)  
❌ Provider API credentials (security)  

## Requesting Production Data

Anonymized logs available upon request with Data Use Agreement.

**Contact:** m24ds001@kitsw.ac.in  
**Subject:** "Data Request - Streaming Multi-Expert Paper"  
**Include:** Institution, research purpose, IRB approval (if applicable)
